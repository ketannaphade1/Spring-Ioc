package com.yash.SpringIOCAssignment_2.model;

public class PrintMessage {

	private String message="yash";

	@Override
	public String toString() {
		return "PrintMessage [message=" + message + "]";
	}
	

}
