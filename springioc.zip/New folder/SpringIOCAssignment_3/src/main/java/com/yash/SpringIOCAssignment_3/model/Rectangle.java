package com.yash.SpringIOCAssignment_3.model;

public class Rectangle extends Shape{
	
	@Override
	void draw() {
		// TODO Auto-generated method stub
		
		System.out.println("draw method of rectangle.....");
	}

}
