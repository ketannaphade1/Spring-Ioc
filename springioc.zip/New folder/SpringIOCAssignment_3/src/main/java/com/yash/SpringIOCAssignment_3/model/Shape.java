package com.yash.SpringIOCAssignment_3.model;

public abstract class Shape {

	 abstract void draw();

}
