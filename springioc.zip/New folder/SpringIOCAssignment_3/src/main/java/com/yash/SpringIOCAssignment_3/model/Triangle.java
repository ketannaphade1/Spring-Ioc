package com.yash.SpringIOCAssignment_3.model;

public class Triangle extends Shape{
	
	@Override
	void draw() {
		// TODO Auto-generated method stub
		
		System.out.println("draw method of triangle.....");
	}

}
