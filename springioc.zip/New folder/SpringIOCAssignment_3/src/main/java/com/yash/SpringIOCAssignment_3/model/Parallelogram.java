package com.yash.SpringIOCAssignment_3.model;

public class Parallelogram extends Shape{
	
	@Override
	void draw() {
		// TODO Auto-generated method stub
		System.out.println("draw method of Parallelogram.....");
	}

}
